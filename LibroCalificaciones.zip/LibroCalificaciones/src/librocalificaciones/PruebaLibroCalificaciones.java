/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package librocalificaciones;

/**
 *Crea un objeto LibroCalificaciones y llama a su método mostrarMensaje
 * @author gear_
 */

//Creamos la clase PruebaLibroCalificaciones, es donde vamos a ejecutar el codigo
public class PruebaLibroCalificaciones {
    
    public static void main(String []args)
    {
        /*Crea un objeto LibroCalificaciones y lo asigna a miLibroCalificaciones
        
        LibroCalificaiones es la clase y miLibroCalificaciones es un objeto de esa clase;
        por lo tanto miLibroCalificaciones va a tener los metodos y atributos de LibroCalificaciones
        */
        LibroCalificaciones miLibroCalificaciones = new LibroCalificaciones(); //Asi se crea un objeto
        
        // llama al método mostrarMensaje de miLibroCalificaciones
        miLibroCalificaciones.mostrarMensaje(); //Asi es como se llaman los metodos 
        
    }//fin del metodo main
}//fin de la clase PruebaLibroCalificaciones
