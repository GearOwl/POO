/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package librocalificaciones;

/**
 *
 * @author gear_
 */
//Creamos la clase LibroCalificaciones
public class LibroCalificaciones {

    //Metodo: Muestra un mensaje de bienvenida al usuario de LibroCalificaciones
    public void mostrarMensaje()
    {
        //Imprimir el mensaje
        System.out.println(  "Bienvenido al libro de calificaciones" );
        
    }// fin del método mostrarMensaje
}//Fin de la clase LibroCalificaciones
